var quizQuestions = [
  {
      id: 1,
      question: "Who won 2011 worldcup ?",
      answers: [
          {
              type: "Microsoft",
              content: "India"
          },
          {
              type: "Nintendo",
              content: "Australia"
          },
          {
              type: "Sony",
              content: "South africa"
          },{
            type: "Sony",
            content: "West indies"
        }
      ],
      correctAnswer: 'India'
  },
  {
      id: 2,
      question: "What is the current year?",
      answers: [
          {
              type: "Microsoft",
              content: "2000"
          },
          {
              type: "Nintendo",
              content: "2010"
          },
          {
              type: "Sony",
              content: "2020"
          },{
            type: "Sony",
            content: "2030"
        }
      ],
      correctAnswer: '2020'
  },
  {
      id: 3,
      question: "what is the current month?",
      answers: [
          {
              type: "Microsoft",
              content: "January"
          },
          {
              type: "Nintendo",
              content: "August"
          },
          {
              type: "Sony",
              content: "March"
          },{
            type: "Sony",
            content: "December"
        }
      ],
      correctAnswer: 'March'
  },
  {
      id:4,
      question: "Who is the Ronaldo",
      answers: [
          {
              type: "Microsoft",
              content: "Football player"
          },
          {
              type: "Nintendo",
              content: "Crickter"
          },
          {
              type: "Sony",
              content: "Tennis player"
          },{
            type: "Sony",
            content: "Rugby player"
        },

      ],
      correctAnswer: 'Football player'
  },
];

export default quizQuestions;
